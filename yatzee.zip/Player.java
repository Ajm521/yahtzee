
import java.util.ArrayList;

public class Player {

  int[] scoreCard;

  public Player() {
    scoreCard = new int[13];
    for (int i = 0; i < 13; i++) {
      scoreCard[i] = -1;
    }
  }

  public void addScore(int place, ArrayList<Integer> arr) {
    
    if (place <= 6&&place>0) {
      scoreCard[place - 1] = (Main.numInArray(place, arr) * place);
    }
    else if (place == 7) {
      for (int i = 1; i < 7; i++) {
        int num = (Main.numInArray(i, arr));
        if (num >= 3) {
          scoreCard[place - 1] = Main.total(Main.listToArray(arr));
        }
      }
    }

    else if (place == 8) {
      for (int i = 1; i < 7; i++) {
        int num = (Main.numInArray(i, arr));
        if (num >= 4) {
          scoreCard[place - 1] = Main.total(Main.listToArray(arr));
        }
      }
    }

    else if (place == 9) {
      if (sizeStrait(arr) >= 4)
        scoreCard[place - 1] = 30;
      else
        scoreCard[place - 1] = 0;
    } else if (place == 10) {
      if (sizeStrait(arr) > 4)
        scoreCard[place - 1] = 40;
      else
        scoreCard[place - 1] = 0;
    } else if (place == 11) {
      boolean l = false;
      boolean j = false;
      for (int i = 1; i < 7; i++) {
        int num = (Main.numInArray(i, arr));
        l = l || num == 2;
        j = j || num == 3;
      }
      if (l && j)
        scoreCard[place - 1] = 25;
      else
        scoreCard[place - 1] = 0;
    }

    else if (place == 12) {
      scoreCard[place - 1] = Main.total(Main.listToArray(arr));
    } 
    else if (place == 13) {
      for (int i = 1; i < 7; i++) {
        int num = (Main.numInArray(i, arr));
        if (num >= 5) {
          if (scoreCard[place - 1] == -1||scoreCard[place - 1] == 0) {
            scoreCard[place - 1] = 50;
            i=10;
          }
          else{
            scoreCard[place - 1] = scoreCard[place - 1] + 100;
          i=10;
          }
        } 
        else if(scoreCard[place-1]==-1) {
          scoreCard[place - 1] = 0;
        }

      }

    }

  }

  public static int sizeStrait(ArrayList<Integer> arr) {
    int count = 0;
    int tempCount = 1;
    int x=0;
    int[] ar = (Main.simpleSort(Main.listToArray(arr)));
//Main.printArray(ar);
    for (int i = 0; i < ar.length-1; i++) {
      if (ar[i+1] == (1 + ar[i])) {
        //System.out.println("i "+i);
        tempCount++;
      } else {
        if (tempCount >= count){ count=tempCount;
      }
        //System.out.println("h"+ar[i]+""+ar[i+1]);
        tempCount = 0;
        x=1;
      }
    }
    if (tempCount > count){
      count = tempCount+x;
    }
    

    return count;
  }

  public int finalScore() {
    int total = 0;
    int partSum = 0;
    for (int i = 0; i < 6; i++) {
      if (scoreCard[i] > 0)
        partSum += scoreCard[i];
    }
    if (partSum >= 63) {
      total = partSum + 35;
    } else {
      total = partSum;
    }
    for (int i = 6; i < 13; i++) {
      if (scoreCard[i] > 0)
        total += scoreCard[i];
    }
    return total;

  }


  public int finalScoreW() {
    int total = 0;
    int partSum = 0;
    for (int i = 0; i < 6; i++) {
      if (scoreCard[i] > 0)
        partSum += scoreCard[i];
    }
    if (partSum >= 63) {
      total = partSum + 0;
    } else {
      total = partSum;
    }
    for (int i = 6; i < 13; i++) {
      if (scoreCard[i] > 0)
        total += scoreCard[i];
    }
    return total;

  }

  public int[] getScoreCard(){
    return scoreCard;
  }
  
}