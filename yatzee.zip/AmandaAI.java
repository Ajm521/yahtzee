
import java.lang.Math;
import java.util.ArrayList;

public class AmandaAI extends Player {

  ArrayList<Integer> places;

  public AmandaAI() {
    super();
    places = new ArrayList<Integer>();
    for (int i = 1; i < 14; i++) {
      places.add(i);
    }
  }

  public int[] randDecision() {
    int[] arr = new int[5];
    for (int i = 0; i < arr.length; i++) {
      arr[i] = (int) (Math.random() * 2);
    }
    return arr;
  }

public int[] Decision(int [] roll)
  {
    //Main.printArray(roll);
  int[] arr = new int[5];
  int[] ones = new int[6];
  
  for(int i = 1;i<7;i++)
  {
    ArrayList<Integer> numbers = Main.arrayToList(roll);
   // System.out.println("there are " + Main.numInArray(i,numbers)+ " "+i+"s in the dice");
    
    
  //if(ones[5])
    //arr[i]=
  }
    
  return arr;
}

  public int randPlace(ArrayList<Integer> arr) {
    int ans = places.remove((int) (Math.random() * places.size()));
  //  ans=13;
    
    boolean r = false;
    for (int i = 1; i < 7; i++) {
      r = r || 5 == Main.numInArray(i, arr);
    }
    if (ans == 13 && super.scoreCard[12] != 0 && r) {
      places.add(13);
    }

    return ans;
  }


 public int[] mathDecision(int[] array){
      int bg=Main.bigSet(array);
    int[] ans=new int[array.length];
    for(int i=0;i<array.length;i++){
      if(array[i]==bg%10){
        ans[i]=1;
      }
    }
    return ans;
  }
  
}