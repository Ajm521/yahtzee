
import java.lang.Math;
import java.util.Scanner;
import java.util.ArrayList;



class Main {
  public static void main(String[] args) {
    Scanner input = new Scanner(System.in);




    
    
System.out.println("how many players would you like?");
    int ttt = input.nextInt();
    int[] totals = new int[ttt];
    int[] totals2 = new int[ttt];
    int [] maths = new int[ttt*26];
  
        
    for (int xx = 0; xx < ttt; xx++) {
     
  AidenAI A =new AidenAI();
     // Player A = new Player();
   boolean bool=(int)(Math.random()*.5*ttt)==42;
      for (int x = 0; x < 13; x++) {
     
        int numDice = 5;
        int count = 0;
        // int[] roll=new int[numDice];
        ArrayList<Integer> score = new ArrayList<Integer>();
        int[] decision = new int[5];
        // roll=rollDice(numDice);
        int h;
        for (int i = 0; i < 3; i++) {
         // System.out.println();
         // System.out.println(numDice);
         // System.out.println(score.size());
         // System.out.println();

          for (int j = 0; j < numDice; j++) {
            h = rollDice(1)[0];
            score.add(h);
          }
          numDice = 5;

          //
          // printArray(roll);
          //printArray(score);
          //
          // for(int j=0;j<numDice;j++){ }

          if (i < 2) {
          
          /*
            for (int j = 0; j < score.size(); j++) {
              decision[j] = input.nextInt();
            }
*/

decision=A.mathDecision(listToArray(score),i);
    
          }
          else {
            for (int j = 0; j < score.size(); j++) {
              decision[j] = 1;
            }
          }
            // printArray(decision);

            int w = 0;

            for (int j = 0; j < score.size(); j++) {

              if (decision[j + w] != 1) {
                //System.out.println("youre removing a " + score.get(j) + " from index " + j);
                score.remove(j);
                j--;
                w++;
                // score.add(roll[j]);
              } 
              else {

                // System.out.println();
                // System.out.println();
                // System.out.println("whats going on");
                // System.out.println();
                // System.out.println();

                count++;
                numDice--;

              }

            }
     
            }
           //  System.out.println();
          //System.out.println();
          //printArray(score);
          //int c = input.nextInt();
          int c=A.ndPlace(score);
         maths[xx+x]=bigSet(listToArray(score))/10;
          A.addScore(c, score);
        if(bool){
   printArray(A.getScoreCard());
        }
          int num = A.finalScore();
         // System.out.println(num);
          }
/*
          System.out.println();
          System.out.println();
          printArray(score);
          //int c = input.nextInt();
          int c=A.dPlace(listToArray(score));
          A.addScore(c, score);

          int num = A.finalScore();
          System.out.println(num);
          
*/

            int num = A.finalScore();
        //System.out.println(num);
        totals[xx] = num;
        }
       
      

     
    for (int xx = 0; xx < ttt; xx++) {
       
 AmandaAI B =new AmandaAI();
     // Player A = new Player();
     
      for (int x = 0; x < 13; x++) {
        int numDice = 5;
        int count = 0;
        // int[] roll=new int[numDice];
        ArrayList<Integer> score = new ArrayList<Integer>();
        int[] decision = new int[5];
        // roll=rollDice(numDice);
        int h;
        for (int i = 0; i < 3; i++) {
          //System.out.println();
          //System.out.println(numDice);
          //System.out.println(score.size());
//          System.out.println();

          for (int j = 0; j < numDice; j++) {
            h = rollDice(1)[0];
            score.add(h);
          }
          numDice = 5;

          //
          // printArray(roll);
         // printArray(score);
          //
          // for(int j=0;j<numDice;j++){ }

          if (i < 2) {
          
          /*
            for (int j = 0; j < score.size(); j++) {
              decision[j] = input.nextInt();
            }
*/

decision=B.mathDecision(listToArray(score));
    
          }
          else {
            for (int j = 0; j < score.size(); j++) {
              decision[j] = 1;
            }
          }
            // printArray(decision);

            int w = 0;

            for (int j = 0; j < score.size(); j++) {

              if (decision[j + w] != 1) {
               // System.out.println("youre removing a " + score.get(j) + " from index " + j);
                score.remove(j);
                j--;
                w++;
                // score.add(roll[j]);
              } else {

                // System.out.println();
                // System.out.println();
                // System.out.println("whats going on");
                // System.out.println();
                // System.out.println();

                count++;
                numDice--;

              }

            }
            for (int j = 0; j < count; j++) {

            }
          }

        //  System.out.println();
          //System.out.println();
          //printArray(score);
          //int c = input.nextInt();
          int c=B.randPlace(score);
          B.addScore(c, score);
  maths[xx+x+(ttt*13)]=bigSet(listToArray(score))/10;
          int num = B.finalScore();
       //   System.out.println(num);

        }
        int num = B.finalScore();
       // System.out.println(num);
        totals2[xx] = num;
      }

    

    System.out.println();
System.out.println();

for(int i=1;i<6;i++){
  double dsa=numInArray(i,arrayToList(maths));
    System.out.println(dsa);
  System.out.println(dsa/(maths.length));
}

    System.out.println();
      System.out.println(calculateMean(maths));
System.out.println();

    
    

    
double w=0;
    double t=0;
    double l=0;
    for(int i=0;i<totals.length;i++){
      if(totals[i]>totals2[i]){
        w++;
      }
      else if(totals2[i]==totals[1]){
        t++;
      }
      else if(totals[i]<totals2[i]){
        l++;
      }
    }
    System.out.println("Aiden: " + w + "\nAmanda: "+ l +"\nties: " + t);
    System.out.println((w/totals.length)*100+"%");
      System.out.println((l/totals.length)*100+"%");
    System.out.println((t/totals.length)*100+"%");

double ff=calculateFitnessScore(totals);
 double f=calculateFitnessScore(totals2);
    
System.out.println("Aiden: " + ((ff/(f+ff))*100) + "\nAmanda: "+((f/(f+ff))*100)+"\ndiff: "+(((ff/(f+ff))*100)-(((f/(f+ff))*100))));
    System.out.println("Aiden median "+calculateMedian(totals));
    System.out.println("Amanda median "+calculateMedian(totals2));


    System.out.println();
System.out.println();

    
      //printArray(totals);
    
    double sum=0.0;
    /*
    for(int i=0;i<totals.length;i++){
      sum+=totals[i];
    }
    System.out.println(sum/totals.length);
    */
    System.out.println("average "+calculateMean(totals));
    System.out.println("max "+max(totals));
      System.out.println("min "+min(totals));
System.out.println("Variance "+calculateVariance(totals));
System.out.println("Standard Deviation "+calculateStandardDeviation(totals));
    System.out.println("Skewness "+calculateSkewness(totals));
    System.out.println("Kurtosis "+calculateKurtosis(totals));
    
    System.out.println("Fitness "+ff);



    System.out.println();
System.out.println();
    
//printArray(totals2);
    double su=0.0;
    /*
    for(int i=0;i<totals2.length;i++){
      su+=totals2[i];
    }
    System.out.println(su/totals2.length);
    */
     System.out.println("average "+calculateMean(totals2));
    System.out.println("max "+max(totals2));
      System.out.println("min "+min(totals2));
System.out.println("Variance "+calculateVariance(totals2));
System.out.println("Standard Deviation "+calculateStandardDeviation(totals2));
    System.out.println("Skewness "+calculateSkewness(totals2));
    System.out.println("Kurtosis "+calculateKurtosis(totals2));
   
    System.out.println("Fitness "+f);




    /*
    MergeSort.sort(totals,0,totals.length-1);
     MergeSort.sort(totals2,0,totals2.length-1);
  System.out.println();
  
double ww=0;
    double tt=0;
    double ll=0;
    for(int i=0;i<totals.length;i++){
      if(totals[i]>totals2[i]){
        ww++;
      }
      else if(totals2[i]==totals[1]){
        tt++;
      }
      else{
        ll++;
      }
    }
    System.out.println("Aiden: " + ww + "\nAmanda: "+ll+"\nties: "+tt);
    System.out.println((ww/totals.length)*100+"%");
      System.out.println((ll/totals.length)*100+"%");
    System.out.println((tt/totals.length)*100+"%");
    
    */
    
    }
    

    /*
    int[] arr=new int[5];
    for(int i=0;i<arr.length;i++){
      arr[i]=input.nextInt();
    }
    for(int i=1;i<7;i++){
      System.out.println(numInArray(i,arrayToList(arr)));
    }
System.out.println();
  
System.out.println(Player.sizeStrait(arrayToList(arr)));
   System.out.println();
    printArray(arr);
    */
  

public static int max(int[] arr){
  int max=-999;
  for(int i=0;i<arr.length;i++){
    if(arr[i]>max){
      max=arr[i];
    }
  }
  return max;
}

  public static double calculateMedian(int[] array) {
        // Sort the array in ascending order
        MergeSort.sort(array,0,array.length-1);

        int length = array.length;
        if (length % 2 == 0) {
            // If the length is even, average the middle two elements
            int middleIndex = length / 2;
            return (array[middleIndex - 1] + array[middleIndex]) / 2.0;
        } else {
            // If the length is odd, return the middle element
            int middleIndex = length / 2;
            return array[middleIndex];
        }
  }


public static double calculateVariance(int[] data) {
    double mean = calculateMean(data);
    double sumSquaredDiff = 0.0;
    for (double value : data) {
        double diff = value - mean;
        double squaredDiff = diff * diff;
        sumSquaredDiff += squaredDiff;
    }
    double variance = sumSquaredDiff / data.length;
    return variance;
}

public static double calculateStandardDeviation(int[] data) {
    double variance = calculateVariance(data);
    double standardDeviation = Math.sqrt(variance);
    return standardDeviation;
}

public static double calculateMean(int[] data) {
    double sum = 0.0;
    for (double value : data) {
        sum += value;
    }
    double mean = sum / data.length;
    return mean;
}


  public static double calculateSkewness(int[] data) {
    int n = data.length;
    double mean = calculateMean(data);
    double sum = 0.0;
    double sumCubedDiff = 0.0;
    
    for (int i = 0; i < n; i++) {
        double diff = data[i] - mean;
        sum += diff;
        sumCubedDiff += diff * diff * diff;
    }
    
    double variance = calculateVariance(data);
    double skewness = (sumCubedDiff / n) / Math.pow(variance, 1.5);
    
    return skewness;
}

public static double calculateKurtosis(int[] data) {
    int n = data.length;
    double mean = calculateMean(data);
    double sum = 0.0;
    double sumFourthDiff = 0.0;
    
    for (int i = 0; i < n; i++) {
        double diff = data[i] - mean;
        sum += diff;
        sumFourthDiff += diff * diff * diff * diff;
    }
    
    double variance = calculateVariance(data);
    double kurtosis = (sumFourthDiff / n) / (variance * variance);
    
    return kurtosis;
}

public static double calculateFitnessScore(int[] scores) {
    double mean = calculateMean(scores);
    double variance = calculateVariance(scores);
    double standardDeviation = calculateStandardDeviation(scores);
    double skewness = calculateSkewness(scores);
    double kurtosis = calculateKurtosis(scores);
  double median = calculateMedian(scores);

    // Define weights for each statistical measure
    double weightMean = 0.58;
    double weightVariance = -0.00;
    double weightStandardDeviation = -0.16;
    double weightSkewness = 0.28;
    double weightKurtosis = 0.0916*skewness;
    double weightMedian = 0.37;
    // Calculate the fitness score using weighted average
    double fitnessScore =(median * weightMedian)+ (weightMean * mean) +
                          (weightVariance * variance) +
                          (weightStandardDeviation * standardDeviation) +
                          (weightSkewness * skewness) +
                          (weightKurtosis * (kurtosis-3));

    return fitnessScore;
}

  
  public static int min(int[] arr){
  int max=9999;
  for(int i=0;i<arr.length;i++){
    if(arr[i]<max){
      max=arr[i];
    }
  }
  return max;
}

  
  public static int[] rollDice(int num) {
    int[] dice = new int[num];
    for (int i = 0; i < num; i++) {
      dice[i] = (int) (Math.random() * 6) + 1;
      //System.out.println("you rolled a " + dice[i]);
      //dice[i]=6;
    }
    return dice;
  }

  public static void printArray(int[] arr) {
    for (int i = 0; i < arr.length; i++) {
      System.out.print(arr[i] + " ");
    }
    System.out.println();
  }

  public static void printArray(ArrayList<Integer> arr) {
    for (int i = 0; i < arr.size(); i++) {
      System.out.print(arr.get(i) + " ");
    }
    System.out.println();
  }

  public static int numInArray(int num, ArrayList<Integer> arr) {
    int count = 0;
    for (int i = 0; i < arr.size(); i++) {
      if (arr.get(i) == num)
        count++;
    }
    return count;
  }

  public static ArrayList<Integer> arrayToList(int[] arr) {
    ArrayList<Integer> list = new ArrayList<Integer>();
    for (int i = 0; i < arr.length; i++) {
      list.add(arr[i]);
    }
    return list;
  }

  public static int[] listToArray(ArrayList<Integer> list) {
    int[] arr = new int[list.size()];
    for (int i = 0; i < arr.length; i++) {
      arr[i] = list.get(i);
    }
    return arr;
  }

  public static int[] simpleSort(int[] arr) {

    int temp;
    int min;
    for (int i = 0; i < arr.length; i++) {
      min = i;
      for (int j = i + 1; j < arr.length; j++) {
        if (arr[j] < arr[min]) {
          min = j;
        }
      }
      temp = arr[i];
      arr[i] = arr[min];
      arr[min] = temp;
    }

    return arr;
  }

  public static int total(int[] arr) {
    int sum = 0;
    for (int i = 0; i < arr.length; i++) {
      sum += arr[i];
    }
    return sum;
  }

public static boolean contains(ArrayList<Integer> arr,int num){
  for(int i=0;i<arr.size();i++){
    if(arr.get(i)==num){
      return true;
    }
  }
  return false;
}

  public static int bigSet(int[] arr){
    int max=0;
    for(int i=0;i<arr.length;i++){
      if(max<numInArray(i,arrayToList(arr))){
        max=(numInArray(i,arrayToList(arr))*10)+i+1;
      }
    }
    return max;
  }

public static int indexOfArr(int[] arr,int target){
  for(int i=0;i<arr.length;i++){
    if(arr[i]==target)
      return i;
  }
  return -1;
}

public static int indexOfArr(ArrayList<Integer> arr,int target){
  for(int i=0;i<arr.size();i++){
    if(arr.get(i)==target)
      return i;
  }
  return -1;
}  


  public static int bIndexOfArr(ArrayList<Integer> arr,int target){
  for(int i=arr.size()-1;i>=0;i--){
    if(arr.get(i)==target)
      return i;
  }
  return -1;
}  
  
  
}