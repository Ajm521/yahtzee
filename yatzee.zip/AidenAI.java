
import java.lang.Math;
import java.util.ArrayList;

public class AidenAI extends Player{

ArrayList<Integer> places;
  int [] maxxx;
  int [] toad;
  double[] exp;
  double[] eVal;
  
  
public AidenAI(){
  super();
  eVal=new double[13];
  maxxx= new int[]{5,10,15,20,25,30,30,30,30,40,25,30,50};
  toad=new int[]{13,10,9,6,7,5,8,11,4,3,2,1,12};
  exp= new double[] {2.11,4.21,6.32,8.43,10.53,12.64,15.19,5.61,18.48,10.61,9.15,23.33,2.3};
for(int i=0;i<13;i++){
  eVal[i]=maxxx[i]-exp[1];
}
  places=new ArrayList<Integer>();
  for(int i=1;i<14;i++){
    places.add(i);
  }
}

public int[] randDecision(){
  int[] arr=new int[5];
  for(int i=0;i<arr.length;i++){
    arr[i]=(int) (Math.random() * 2);
  }
  return arr;
}

public int randPlace(ArrayList<Integer> arr){
int ans=places.remove((int) (Math.random() * places.size()));
  boolean r=false;
  for(int i=1;i<7;i++){
   r=r||5== Main.numInArray(i,arr);
  }
if(ans==13 && super.scoreCard[12]!=0 && r){
  places.add(13);
} 
  return ans;
}

  public int dPlace(ArrayList<Integer> arr){
int max=-999;
    int max2=-999;
    int ans;
    int an=0;
    int an2=0;
    int cScore=this.finalScore();
    int diff1;
    for(int i=0;i<places.size();i++){
      
      this.addScore(places.get(i),arr);
diff1=this.finalScore()-cScore;
      if(diff1>max){
        max2=max;
        max=diff1;
        an2=an;
       an=i; 
      }
     
      super.scoreCard[places.get(i)-1]=-1;
    
    }
    if(max==max2&&an2<an){
  ans=places.remove(an2);
    }
    else
    ans=places.remove(an);

    boolean r=false;
  for(int i=1;i<7;i++){
   r=r||5== Main.numInArray(i,arr);
  }
if(ans==13 && super.scoreCard[12]!=0 && r){
  places.add(13);
  
}
    return ans;
  }
  
public int[] dDecision(int[] array,int roll){
int[] arr=new int[5];

boolean l = false;
      boolean j = false;
      for (int i = 1; i < 7; i++) {
        int num = (Main.numInArray(i, Main.arrayToList(array)));
        l = l || num == 2;
        j = j || num == 3;
      }
    boolean bh=l && j;


  
  
  
boolean r=false;
  for(int i=0;i<array.length;i++){
    r=r||Main.contains(places,array[i]);
  }

  int bg=Main.bigSet(array);

  
if(bh&&Main.contains(places,11)){
  for(int i=0;i<arr.length;i++){
    arr[i]=1;
  }
  return arr;
}

  
  if(r){
    
   for(int i=0;i<arr.length;i++){

     if(roll>=1){

if(bg/10<=3){
       
      if(array[i]>3.5&& Main.contains(places,array[i])){
        arr[i]=1;
      }
}
  
  else if (array[i] == bg%10 && Main.contains(places,array[i]))
{
arr[i]=1;
}
     
  }     
            
     else{
if(bg/10<3){
       
      if(array[i]>4.25&& Main.contains(places,array[i])){
        arr[i]=1;
      }
}
  else if (array[i] == bg%10 && Main.contains(places,array[i]))
{
arr[i]=1;
}
     }

    }
    
  }
    
  else{

 int ss= super.sizeStrait(Main.arrayToList(array));
    
if(bg/10<=ss && (Main.contains(places,9) || Main.contains(places,10) )){

  int nnn;
      for(int i=0;i<arr.length;i++){
        nnn=array[i];
        array[i]=-2;
        if(ss<=super.sizeStrait(Main.arrayToList(array))){
          arr[i]=0;
        }
        else{
          arr[i]=1;
           array[i]=nnn;
        }
      
      }
  
}
    else{
     
for(int i=0;i<arr.length;i++){

  if(bg/10<3){
    if(array[i]==bg%10){
      arr[i]=1;
    }
  else {    
      if(roll>=1){
    if(array[i]>3.5){
      arr[i]=1;
    }
    }
    else{
          if(array[i]>4.25){
      arr[i]=1;
    }
    }
  }
  }
  else{
    if(roll>=1){
    if(array[i]>3.5){
      arr[i]=1;
    }
    }
    else{
          if(array[i]>4.25){
      arr[i]=1;
    }
    }
  }
  
  }   
      
    }   
  }
  
  return arr;
}

 public int ndPlace(ArrayList<Integer> arr){
   
   int[] minss=new int[places.size()];
      int[] minsss=new int[places.size()];
int max=999;
    
    int place=0;
    int ans;
    int an=0;
    
    int cScore=this.finalScore();
    int diff1;
    for(int i=0;i<places.size();i++){
      int bug=super.scoreCard[places.get(i)-1];
      this.addScore(places.get(i),arr);
      int di=(this.finalScore()-cScore);
      
diff1= maxxx[places.get(i)-1] - di;
      minss[i]=i;
      minsss[i]=diff1;
      if(diff1 < max){
        max=diff1;        
        an=i; 
      }

 
      super.scoreCard[places.get(i)-1]=bug;



      
    }

int di=7;
   if(di!=0||true){
   for(int i=0;i<minss.length;i++){
     if(minsss[i]!=max){
       minss[i]=-1;
     }
   }
   }
 
       
    /*
    ans=places.remove(an);
    
    boolean r=false;
  for(int i=1;i<7;i++){
   r=r||5== Main.numInArray(i,arr);
  }
if(ans==13 && super.scoreCard[12]!=0 && r){
  places.add(13);
  
}
    return ans;
   */
   
   return ccPlace(arr,minss);
   

   
  }

   public int auxPlace(ArrayList<Integer> arr,int[] place){
int max=-999;
    int ans;
    int an=0;
    
    int cScore=this.finalScore();
    int diff1;
     
  
    for(int i=0;i<place.length;i++){
      if(place[i]>0){
   this.addScore(places.get(place[i]),arr);
                  
diff1=this.finalScore()-cScore;
      if(diff1>max){
        
        max=diff1;
       
       an=i; 
      }
      super.scoreCard[place[i]-1]=-1;
      
    }
  }
   


      ans=places.remove(place[an]);
    
    boolean r=false;
  for(int i=1;i<7;i++){
   r=r||5== Main.numInArray(i,arr);
  }
if(ans==13 && super.scoreCard[12]!=0 && r){
  places.add(13);
  
}
    return ans;
  }

   public int axPlace(ArrayList<Integer> arr,int[] pl){
     int ans;
int min=999;
     for(int i=0;i<pl.length;i++){
       if(pl[i]>-1){

if(Main.indexOfArr(toad,places.get(pl[i]))<min){
  min= Main.indexOfArr(toad,places.get(pl[i]));
}
         
       }
     }
  
     ans = places.remove(Main.indexOfArr(places, toad[min]));

     
    boolean r=false;
  for(int i=1;i<7;i++){
   r=r||5== Main.numInArray(i,arr);
  }
if(ans==13 && super.scoreCard[12]!=0 && r){
  places.add(13);
  
}
    return ans;
    
  }


public int cPlace(ArrayList<Integer> arr, int[] place) {
    int max = -999;
    int min = 999;
    int maxIndex = 0;
    
    int cScore = this.finalScore();
    int diff1;
    
    for (int i = 0; i < place.length; i++) {
        if (place[i] > 0) {
            this.addScore(places.get(place[i]), arr);
            diff1 = this.finalScore() - cScore;
            if (diff1 > max) {
                max = diff1;
                maxIndex = i;
            }
            super.scoreCard[place[i] - 1] = -1;
        }
        
        if (place[i] > -1) {
            if (Main.indexOfArr(toad, places.get(place[i])) < min) {
                min = Main.indexOfArr(toad, places.get(place[i]));
            }
        }
    }
   
    int ans;

int aux = places.get(place[maxIndex]);
  int ax = places.get(Main.indexOfArr(places, toad[min]));
  
    if (max > 0) {
        ans = places.remove(place[maxIndex]);
    } 
    else {
        ans = places.remove(Main.indexOfArr(places, toad[min]));
    }


  
    boolean r = false;
    for (int i = 1; i < 7; i++) {
        r = r || 5 == Main.numInArray(i, arr);
    }
    
    if (ans == 13 && super.scoreCard[12] != 0 && r) {
        places.add(13);
    }
    
    return ans;
}


public int ccPlace(ArrayList<Integer> arr, int[] place){

  
  int ans;
  double min=-999.9;
  int an=0;
  for(int i=0;i<place.length;i++){
   
    if(place[i]!=-1){
    double temp=exp[place[i]];
    if(temp>min){
      min=temp;
        an=i;
    }
    }

 if(place[i]==12){
      an=i;
   i=111;
    }
    
  }


 ans = places.remove(an);

     
    boolean r=false;
  for(int i=1;i<7;i++){
   r=r||5== Main.numInArray(i,arr);
  }
if(ans==13 && super.scoreCard[12]!=0 && r){
  places.add(13);
}
    return ans;
    

  
}
  
/*
  public double exValue(int place){
    if(place<=6){
for(int i=0;i<3;i++){
  return 2.1089*place;
}
    }
    else if(place == 7){
      return 15.19;
    }
    else if(place ==8){
      return 
    }

   return 0.0; 
  }

  public static double f(int x,int d){
if(x>d||x<0)return 0;
    
    double ans =(Math.pow(1.0/6,x))*(Math.pow(5.0/6,d-x));
    return ans;
  }


  public static double z(int x,int d){
    if(x>d||x<0)return 0;
    double ans=1.0;
double[] arr=new double[d];
    for(int i=0;i<arr.length;i++){
      arr[i]=f(i,d);
    }
    for(int i=1;i<=x;i++){
    ans*=(1.0-(arr[x-i]*f(i-(d-x),i)));
      //System.out.println((1.0-(arr[x-i]*f(i-(d-x),i))));
      }
    return 1.0-ans;
  }


   public static double h(int x,int d){
    if(x>d||x<0)return 0;
    double ans=1.0;
double[] arr=new double[d];
    for(int i=0;i<arr.length;i++){
      arr[i]=z(i,d);
    }
    for(int i=1;i<=x;i++){
    ans*=(1.0-(arr[x-i]*f(i-(d-x),i)));
      }
    return 1.0-ans;
  }
  */


  public int[] mathDecision(int[] array,int roll){
      int bg=Main.bigSet(array);
    int[] ans=new int[array.length];
    for(int i=0;i<array.length;i++){
      if(array[i]==bg%10){
        ans[i]=1;
      }
    }
    return ans;
  }
  
}